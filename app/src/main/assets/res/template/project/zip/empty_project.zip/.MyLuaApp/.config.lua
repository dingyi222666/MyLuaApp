iconPath="app/src/main/res/drawable/ic_launcher.png"
appName="$app_name"
appPackageName="$app_package_name"
