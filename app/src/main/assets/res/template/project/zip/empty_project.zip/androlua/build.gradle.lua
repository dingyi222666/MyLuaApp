plugins {
  id 'com.android.library'
}
android {
    compileSdkVersion (30),
    buildToolsVersion "30.0.3",

    defaultConfig {      
        minSdkVersion (21),
        targetSdkVersion (28),
        versionCode (5008),
        versionName "5.0.8"
    },
    buildTypes {
        release {
            minifyEnabled (false),
            proguardFiles (getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro')
        }
    },
    
}

dependencies {
    implementation (fileTree('libs',{'*.jar'}))
}
