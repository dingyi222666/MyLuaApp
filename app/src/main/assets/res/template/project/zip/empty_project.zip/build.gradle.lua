buildscript {
    ext {
      build_gradle_version = '3.6.1'
    },

    repositories {
        maven { url 'https://maven.aliyun.com/repository/public/' },
        maven { url 'https://maven.aliyun.com/repository/google/' },
        maven { url 'https://maven.aliyun.com/repository/gradle-plugin/' },
        maven { url 'https://dl.bintray.com/ppartisan/maven/' },
        maven { url "https://clojars.org/repo/" },
        maven { url "https://jitpack.io" },
        mavenLocal(),
        mavenCentral(),
    },
    dependencies {
        classpath "com.android.tools.build:gradle:$build_gradle_version"
        
    }
    
}
allprojects {
    repositories {
        maven { url 'https://maven.aliyun.com/repository/public/' } ,
        maven { url 'https://maven.aliyun.com/repository/google/' },
        maven { url 'https://maven.aliyun.com/repository/gradle-plugin/' },
        maven { url 'https://dl.bintray.com/ppartisan/maven/' },
        maven { url "https://clojars.org/repo/" },
        maven { url "https://jitpack.io" },
        mavenLocal(),
        mavenCentral(),
    }
}

--add gradle code in this
gradleCode {[[
task clean(type: Delete) {
    delete rootProject.buildDir
}
]]}