ext = {
      build_gradle_version = '3.6.1'
}

buildscript = {
    repositories = {
        maven ('https://maven.aliyun.com/repository/public/'),
        maven ('https://maven.aliyun.com/repository/google/'),
        maven ('https://maven.aliyun.com/repository/gradle-plugin/'),
        maven ('https://dl.bintray.com/ppartisan/maven/'),
        maven ("https://clojars.org/repo/"),
        maven ("https://jitpack.io"),
        mavenLocal(),
        mavenCentral(),
    },
    dependencies = {
        classpath "com.android.tools.build:gradle:${build_gradle_version}"
     
    }
    
}

allprojects = {
    repositories = {
        maven ('https://maven.aliyun.com/repository/public/'),
        maven ('https://maven.aliyun.com/repository/google/'),
        maven ('https://maven.aliyun.com/repository/gradle-plugin/'),
        maven ('https://dl.bintray.com/ppartisan/maven/'),
        maven ("https://clojars.org/repo/"),
        maven ("https://jitpack.io"),
        mavenLocal(),
        mavenCentral(),
    }
}

task.register("clean") { function()
  delete(rootProject.buildDir.delete)
end }
