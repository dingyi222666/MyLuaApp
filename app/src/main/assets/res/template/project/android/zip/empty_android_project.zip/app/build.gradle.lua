plugins = {
   'com.android.application'
}
android = {
    compileSdkVersion = 30 ,
    buildToolsVersion  ="30.0.3",

    defaultConfig = {
        applicationId  ="$app_package_name",
        minSdkVersion = 21 ,
        targetSdkVersion = 28,
        versionCode = 1,
        versionName = "1.0"
    },

    buildTypes = {
        release = {
            minifyEnabled = false,
            proguardFiles = { getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro' }
        }
    },
}

dependencies = {
    implementation (fileTree("libs", {"*.jar"})),
}
