include ':app'
rootProject.name = "$app_name"
