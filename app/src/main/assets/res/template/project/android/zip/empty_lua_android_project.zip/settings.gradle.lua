include ':app'
include ':androlua'
rootProject.name = "$app_name"
